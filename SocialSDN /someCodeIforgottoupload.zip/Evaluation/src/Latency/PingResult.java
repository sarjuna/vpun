package Latency;

public class PingResult {
  private double responseTime;

public double getResponseTime() {
	return responseTime;
}

public void setResponseTime(double responseTime) {
	this.responseTime = responseTime;
}
  
	
	
}
