package net.floodlightcontroller.mactracker;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class HttpSplashPage {
	
	public void sendAuthenticationRespone(){
		URL url;
		HttpURLConnection connection = null; 
		try {
			String token = getToken();
			url = new URL("http://192.168.142.1:2050/nodogsplash_auth/?tok="+token+"&nodogpass=nodog");
			connection = (HttpURLConnection) url.openConnection();
			
			
			connection.setRequestMethod("GET");
			
		
			int responseCode = connection.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

		} catch (IOException e) {
			System.out.println(e);
		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
	}
	
	public  String getToken(){
		URL url;
		HttpURLConnection connection = null; 
		try {
			url = new URL("http://192.168.142.1:2050");
			connection = (HttpURLConnection) url.openConnection();
			
			connection.setRequestMethod("GET");
			
			int responseCode = connection.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);
	 
			BufferedReader in = new BufferedReader(
			        new InputStreamReader(connection.getInputStream()));
			String inputLine;
	 
			while((inputLine = in.readLine()) != null) {
				if(inputLine.contains("Redirecting")){
					String res[] = inputLine.split(" ");
					return res[2];
				}
			}
			in.close();
	 
	
			
			
			
		} catch (IOException e) {
			System.out.println(e);
		} finally {

			if (connection != null) {
				connection.disconnect();
			}
		}
		
		return "falseToken";
	}

}
