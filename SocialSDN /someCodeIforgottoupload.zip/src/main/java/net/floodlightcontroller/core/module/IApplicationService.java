package net.floodlightcontroller.core.module;

public interface IApplicationService extends IFloodlightService {

}
