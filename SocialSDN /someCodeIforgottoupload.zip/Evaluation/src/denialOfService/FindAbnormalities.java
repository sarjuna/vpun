package denialOfService;

import java.util.List;

import Latency.PingResult;

public class FindAbnormalities {

	List<PingResult> list;

	public void setList(List<PingResult> list) {
		this.list = list;
	}
	
	public void investigate(){
		double a[] = {0,0,0,0};
		int counter=3;
		int i=0;
		int f=0;
		boolean skip=false;
		for(PingResult res:list){
			
			if(!skip){
			if( abnomalityCheck(res, (a[0]+a[1]+a[2]+a[3])/4) && abnomalityCheck(list.get(i+1), (a[0]+a[1]+a[2]+a[3])/4) ){
				System.out.println(counter +" "+res.getResponseTime());
			    skip=true;
			    f=0;
			    counter++;
			}
			
			} else{
				f++;
				if(f==20) skip=false;
			}
		i++;
		}
	}
	private boolean abnomalityCheck(PingResult res, double median){
		
		if(res.getResponseTime() > 10*(median+0.1) &&
				res.getResponseTime()>100
				)
		{
			return true;
		}
		
		return false;
	}
	
}
