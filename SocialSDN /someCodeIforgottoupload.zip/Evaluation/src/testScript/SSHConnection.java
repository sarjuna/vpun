package testScript;

import java.io.InputStream;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class SSHConnection {
	private int port =22;
	  private String password="bismark123";
	  private String host="192.168.142.1";
	  private String user="root";
	  private int sizeOfScript= 4096;
	  
	  public int initialize(){
		  int channelS =0;
		  try
	      {
	      JSch jsch = new JSch();
	      Session session = jsch.getSession(user, host, port);
	          session.setPassword(password);
	          session.setConfig("StrictHostKeyChecking", "no");
	   
	      session.connect();
	      String command1 = "export PATH=/bin:/sbin:/usr/bin:/usr/sbin";
	      //String command2 = "insmod sch_netem";
	      //String command3 = "insmod sch_tbf";
	      String command4 = "ovs-vsctl set-controller br-lan tcp:192.168.142.220:6633";
	      String command5 = "/etc/init.d/nodogsplash start";

	      
	      Channel channel=session.openChannel("exec");
	      ((ChannelExec)channel).setCommand(command1 
	    	//	  + " && "+command2
	    	//	  + " && "+command3
	    		  + " && "+command4
	    		  + " && "+command5
	    		  );
	      
	      channel.setInputStream(null);
	      
	      ((ChannelExec)channel).setErrStream(System.err);
	      
	      InputStream in=channel.getInputStream();
	 
	      channel.connect();
	      
	      byte[] tmp=new byte[sizeOfScript];
	      while(true){
	        while(in.available()>0){
	          int i=in.read(tmp, 0, sizeOfScript);
	          if(i<0)break;
	          System.out.print(new String(tmp, 0, i));
	        }
	        if(channel.isClosed()){
	          System.out.println("exit-status: "+channel.getExitStatus());
	           channelS =  channel.getExitStatus();
	           break;
	        }
	        try{Thread.sleep(1000);}catch(Exception ee){}
	      }
	      channel.disconnect();
	      session.disconnect();
	      return channelS;
	      }
	  catch(Exception e){System.err.print(e);}
		  return -1;
	  }
	  public int tryToInitializeModules(){
		  int channelS =0;
		  try
	      {
	      JSch jsch = new JSch();
	      Session session = jsch.getSession(user, host, port);
	          session.setPassword(password);
	          session.setConfig("StrictHostKeyChecking", "no");
	   
	      session.connect();
	      String command1 = "export PATH=/bin:/sbin:/usr/bin:/usr/sbin";
	      String command2 = "insmod sch_netem";
	      String command3 = "insmod sch_tbf";
	      //String command4 = "ovs-vsctl set-controller br-lan tcp:192.168.142.220:6633";
	      //String command5 = "/etc/init.d/nodogsplash start";

	      
	      Channel channel=session.openChannel("exec");
	      ((ChannelExec)channel).setCommand(command1 
	    		  + " && "+command2
	    		  + " && "+command3
	    	//	  + " && "+command4
	    	//	  + " && "+command5
	    		  );
	      
	      channel.setInputStream(null);
	      
	      ((ChannelExec)channel).setErrStream(System.err);
	      
	      InputStream in=channel.getInputStream();
	 
	      channel.connect();
	      
	      byte[] tmp=new byte[sizeOfScript];
	      while(true){
	        while(in.available()>0){
	          int i=in.read(tmp, 0, sizeOfScript);
	          if(i<0)break;
	          System.out.print(new String(tmp, 0, i));
	        }
	        if(channel.isClosed()){
	          System.out.println("exit-status: "+channel.getExitStatus());
	           channelS =  channel.getExitStatus();
	           break;
	        }
	        try{Thread.sleep(1000);}catch(Exception ee){}
	      }
	      channel.disconnect();
	      session.disconnect();
	      return channelS;
	      }
	  catch(Exception e){System.err.print(e);}
		  return -1;
	  }
}
