package testScript;

public class Starter {

	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          SSHConnection connectionWithRouter = new SSHConnection();
          connectionWithRouter.initialize();
          connectionWithRouter.tryToInitializeModules();
	}

}
