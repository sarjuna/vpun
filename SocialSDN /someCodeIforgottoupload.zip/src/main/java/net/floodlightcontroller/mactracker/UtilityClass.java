package net.floodlightcontroller.mactracker;

import org.openflow.util.HexString;

public class UtilityClass {

	public static String convertMac(long mac){
		String macWithZeros = HexString.toHexString(mac);
		System.out.println("Print mac: "+macWithZeros.substring(6));
		return macWithZeros.substring(6);
	}
	
}
