package controller;

public class Controller {

public static void main(String args[]){
	//TODO:Open ssh connection to the router
	SSHConnection con = new SSHConnection();
	con.establishConnection();
	//TODO:Establish database connection
	
   // TODO:server side logic and commands
}

	
}
